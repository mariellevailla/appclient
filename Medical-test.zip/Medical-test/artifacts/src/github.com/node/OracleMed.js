'use strict';
const shim = require('fabric-shim');
const util = require('util');
const crypto = require('crypto');

var Chaincode = class {
     /* 
    let patient = {
        'docType': string, default 'patient', //docType is used to distinguish the various types of objects in state database         
        'nom': string       //the fieldtags are needed to keep case from bouncing around
        'prénom': string
        'numéroAssurance': integer
        'numéroInstitution' : integer
        'clePrive': integer???
        'clePublique': integer???
        'dossierMedical':???
    };
    
    let dossierMedical ={
        'docType': string
        'infoMed': string
    }
    */
    // Initialize the chaincode
    async Init(stub) {
        console.info('========= Inscription dun nouveau patient =========');
        let ret = stub.getFunctionAndParameters();
        console.info(ret);
        return shim.success();
    }

    async Invoke(stub) {
        console.info('Transaction ID: ' + stub.getTxID());
        let ret = stub.getFunctionAndParameters();
        console.info(ret);
        let method = this[ret.fcn];
        if (!method) {
            console.error('no method of name:' + ret.fcn + ' found');
            throw new Error('Received unknown function ' + ret.fcn + ' invocation');
        }

        console.info('Calling method : ' + ret.fcn + "\n");
        try {
            let payload = await method(stub, ret.params, this);
            return shim.success(payload);
        } catch (err) {
            console.log(err);
            return shim.error(err);
        }
    }

    //Ajouter un nouveau patient
    async addPatient(stub, args, thisClass) {

        let jsonResp = {};

        if (args.length != 4) {
            throw new Error('Incorrect number of arguments. Expecting 4 (Nom, prenom, assurance maladie, Institution');
        }

        console.info('Ajout du patient');
        if (args[0].length <= 0) {
            throw new Error('1st argument must be a non-empty string');
        }
        if (args[1].length <= 0) {
            throw new Error('2nd argument must be a non-empty string');
        }
        if (args[2].length <= 0) {
            throw new Error('3th argument must be a non-empty string');
        }
        if (args[3].length <= 0) {
            throw new Error('4th argument must be a non-empty string');
        }

        let Patient = {};
        Patient.Nom = args[0].toLowerCase();
        Patient.Prenom = args[1].toLowerCase();
        Patient.NumeroAssurance = args[2];
        Patient.Institution = args[3];
        //newPatient.clePublique = clePublique;
        
  // ==== Check if patient already exists ====   
        let patientAsBytes = await stub.getState(Patient.NumeroAssurance);
        if (patientAsBytes.toString()){
            console.info('Ce patient existe deja : ' + Patient.NumeroAssurance);
            jsonResp.Error = 'Ce patient existe deja: ' + Patient.NumeroAssurance;
            throw new Error(JSON.stringify(jsonResp));    
        }
        
        //Creation du dossier 
        Patient.dossier = {};
        var key = 'testtesttesttesttesttesttesttest';
        var cipher = crypto.createCipher('aes-256-cfb', key, 'testtesttesttest');
        var encryptedData = cipher.update(Patient.toString(), 'utf8', 'hex') + cipher.final('hex'); 
       
       
        const buffer = Buffer.from(JSON.stringify(encryptedData));
        await stub.putState(Patient.NumeroAssurance, buffer);
        console.info(Patient);
        console.info(encryptedData);
    }

    async query(stub, args, thisClass) {

        let jsonResp = {};

        if (args.length != 1) {
            throw new Error('Incorrect number of arguments. Expecting numero assurance maladie of the patient to query');
        }

        let numeroAssurance = args[0];

        let patientAsBytes = await stub.getState(numeroAssurance);
        if (!patientAsBytes.toString()){
            console.info('Failed to get patient for: ' + numeroAssurance);
            jsonResp.Error = 'Failed to get patient for: ' + numeroAssurance;
            throw new Error(JSON.stringify(jsonResp));    
        }

        var key = 'testtesttesttesttesttesttesttest';
        var decipher = crypto.createDecipheriv('aes-256-cfb', key, 'testtesttesttest');
        let decryptedData = decipher.update(patientAsBytes, 'hex', 'binary') + decipher.final('binary');
        console.info(patientAsBytes);
        console.info(decryptedData);
        
        return JSON.parse(decryptedData);
        
        jsonResp.numeroAssurance = numeroAssurance;
        jsonResp.dossier = decryptedData.toString();
        console.info(jsonResp);
    }

    async invoke(stub, args, thisClass) {

        let jsonResp = {};
        
        if (args.length != 2) {
            throw new Error('Incorrect number of arguments. Expecting numero assurance maladie of the patient + dossier medical modifier');
        }

        let numeroAssurance = args[0];
        let dossierModif = args[1];

        let patientAsBytes = await stub.getState(numeroAssurance);
        if (!patientAsBytes.toString()){
            console.info('Failed to get patient for: ' + numeroAssurance);
            jsonResp.Error = 'Failed to get patient for: ' + numeroAssurance;
            throw new Error(JSON.stringify(jsonResp));    
        }

        
        var key = 'testtesttesttesttesttesttesttest';
        var decipher = crypto.createDecipheriv('aes-256-cfb', key, 'testtesttesttest');
        let decryptedData = decipher.update(patientAsBytes, 'hex', 'binary') + decipher.final('binary');
         

        let updateDossier = {};
        try{
            updateDossier = JSON.parse(decryptedData.toString('utf8'));
        }catch(err){
            console.info("Failed to decode patient file:" + numeroAssurance);
            jsonResp.Error = "Failed to decode patient file:" + numeroAssurance;
            throw new Error(JSON.stringify(jsonResp));
        }

        updateDossier.dossier = dossierModif;
        var key = 'testtesttesttesttesttesttesttest';
        var cipher = crypto.createCipher('aes-256-cfb', key, 'testtesttesttest');  
        var encryptedData = cipher.update(Patient.toString(), 'utf8', 'hex');
        encryptedData += cipher.final('hex');
      
        let patientJSONBytes = Buffer.from(JSON.stringify(encryptedData));
        await stub.putState(numeroAssurance, patientJSONBytes);
      
    }
};

shim.start(new Chaincode());